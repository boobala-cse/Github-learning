export const NEW = 'new';
export const VERIFIED = 'verified';
export const IN_WORK = 'in_work';
export const READY_FOR_DELIVERY = 'ready_for_delivery';
export const ON_DELIVERY = 'on_delivery';
export const COMPLETED = 'completed';
export const CANCELED = 'canceled';
