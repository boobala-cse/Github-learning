import React, { Component } from 'react';

class NewProduct extends Component {

	render() {
		return (<div>NewProduct</div>);
	}
}

export default NewProduct;
