import React, { Component } from 'react';

class Account extends Component {

	render() {
		return (<div>Account</div>);
	}
}

export default Account;
