import React, { Component } from 'react';

class SiderLogo extends Component {
	render() {
		return (
					<div className="logo">
						<span className="logo1">F</span>
						<span className="logo2">D</span>
					</div>
		);
	}
}

export default SiderLogo;
